#!/usr/bin/env python

import os, sys, argparse, decimal
from datetime import datetime, timezone

MIN_PYTHON = (3, 6)
if sys.version_info < MIN_PYTHON:
  sys.exit("Python %s.%s or later is required.\n" % MIN_PYTHON)

SCRIPTPARENT = os.path.dirname(os.path.abspath(__file__))
CUR_DIR = os.path.abspath(os.curdir)

#LANGDEF, CURDEF, BANKID = 'ENG', 'USD', '00000'
LANGDEF, CURDEF = os.getenv('LANGDEF', 'ENG'), os.getenv('CURDEF', 'USD')
BANKID = os.getenv('BANKID', '00000')
#COLUMNORDER = os.getenv('COLUMNORDER',
#  'account,date,payee,note,amount,comment')
COLUMNORDER = os.getenv('COLUMNORDER',
  'date,code,payee,account,commodity,amount,flag,note')

def deserialize_csv(csvfile):
  import csv
  
  txnlist, csvacct, dateplo, datephi, idx = [], None, None, None, -1
  
  for csvrow in csv.DictReader(csvfile, fieldnames=COLUMNORDER.split(',')):
    if '' == csvrow['account'] or csvrow['date'] in ['date', 'Date']:
      continue
    idx += 1
    csvrow['idx'] = str(idx)
    csvrow['cleared'] = 'X' if '*' == csvrow.get('flag', '!') else ''
    csvrow['trntype'] = 'DEBIT' if 0 > float(csvrow['amount']) else 'CREDIT'
    if None == csvacct:
      csvacct = csvrow['account'].split(':')[-1].upper()
    if None == dateplo or dateplo > csvrow['date']:
      dateplo = csvrow['date']
    if None == datephi or datephi < csvrow['date']:
      datephi = csvrow['date']
    txnlist.append(csvrow)
  
  return (csvacct, txnlist, dateplo, datephi)

def render_sample(templatelib='mustache', ctx=None, qif=False):
  templatebase = 'qifsample.qif' if qif else '{0}msgsrsv1.ofx'.format(
    'creditcard' if 'CREDITCARD' == ctx.get('accttype',
    'CHECKING') else 'bank')
  template = os.path.join(SCRIPTPARENT, '_templates', templatelib,
    '{0}.{1}'.format(templatebase, templatelib))
  datefmt_spec = '%Y/%m/%d' if qif else '%Y%m%d%H%M%S.%f[+0:UTC]'
  for txn in ctx.get('txnlist', []):
    txn['date'] = datetime.strftime(txn['date'], datefmt_spec)
  ctx['baldate'] = datetime.strftime(ctx.get('baldate',
    datetime.now(tz=timezone.utc)), datefmt_spec)
  ctx['dtserver'] = datetime.strftime(ctx.get('dtserver',
    datetime.now(tz=timezone.utc)), datefmt_spec)
  ctx['dtstart'] = datetime.strftime(ctx['dtstart'], datefmt_spec)
  ctx['dtend'] = datetime.strftime(ctx['dtend'], datefmt_spec)
  res = ''
  
  if 'jinja' == templatelib:
    from jinja2 import Environment, FileSystemLoader
    
    res = Environment(loader=FileSystemLoader('/'), trim_blocks=True
      ).get_template(template).render(ctx)
  elif 'liquid' == templatelib:
    # pip install --user python-liquid
    from liquid import Environment, FileSystemLoader
    
    res = Environment(loader=FileSystemLoader('/')).get_template(
      template).render(ctx)
  elif 'mustache' == templatelib:
    #import pystache
    import chevron
    
    #res = pystache.render(open(template, 'r').read(), ctx)
    res = chevron.render(open(template, 'r'), ctx)
  return res

def csv_to_qif(cfg=None):
  import quiffen
  
  qifacct = quiffen.Account(cfg['acctid'],
    account_type=cfg.get('qiftype', 'Bank'), desc=cfg.get('acctdesc', None),
    balance=decimal.Decimal(cfg.get('balamt', '0.00')),
    date_at_balance=cfg.get('baldate', datetime.now(tz=timezone.utc)))
  
  for txn in cfg.get('txnlist', []):
    txnqif = quiffen.Transaction(date=txn['date'],
      amount=decimal.Decimal(txn['amount']), payee=txn['payee'],
      memo=txn['note'], cleared=txn['cleared'])
    qifacct.add_transaction(txnqif, header=cfg.get('qiftype', 'Bank'))
  
  qif = quiffen.Qif()
  qif.add_account(qifacct)
  return qif

def csv_to_ofx(cfg=None):
  from ofxtools import models
  
  stmttrnlist = []
  
  for txn in cfg.get('txnlist', []):
    stmttrnlist.append(models.STMTTRN(trntype=txn['trntype'],
      dtposted=txn['date'], trnamt=decimal.Decimal(txn['amount']),
      name=txn['payee'], memo=txn['note'], fitid=txn['idx']))
  
  ledgerbal = models.LEDGERBAL(
    balamt=decimal.Decimal(cfg.get('balamt', '0.00')),
    dtasof=cfg.get('baldate', datetime.now(tz=timezone.utc)))
  tranlist = models.BANKTRANLIST(*stmttrnlist, dtstart=cfg['dtstart'],
    dtend=cfg['dtend'])
  status = models.STATUS(code=0, severity='INFO')
  bankmsgsrs, creditcardmsgsrs = None, None
  
  if 'CREDITCARD' == cfg.get('accttype', 'CHECKING'):
    acctfrom = models.CCACCTFROM(acctid=cfg['acctid'])
    stmtrs = models.CCSTMTRS(curdef=cfg['curdef'], ccacctfrom=acctfrom,
      banktranlist=tranlist, ledgerbal=ledgerbal)
    stmttrnrs = models.CCSTMTTRNRS(trnuid=cfg['acctid'], status=status,
      ccstmtrs=stmtrs)
    creditcardmsgsrs = models.CREDITCARDMSGSRSV1(stmttrnrs)
  else:
    acctfrom = models.BANKACCTFROM(acctid=cfg['acctid'], bankid=cfg['bankid'], 
      accttype=cfg['accttype'])
    stmtrs = models.STMTRS(curdef=cfg['curdef'], bankacctfrom=acctfrom,
      banktranlist=tranlist, ledgerbal=ledgerbal)
    stmttrnrs = models.STMTTRNRS(trnuid=cfg['acctid'], status=status,
      stmtrs=stmtrs)
    bankmsgsrs = models.BANKMSGSRSV1(stmttrnrs)
  
  sonrs = models.SONRS(status=status, dtserver=cfg['dtserver'],
    language=cfg['langdef'])
  signonmsgs = models.SIGNONMSGSRSV1(sonrs=sonrs)
  ofx = models.OFX(signonmsgsrsv1=signonmsgs, bankmsgsrsv1=bankmsgsrs,
    creditcardmsgsrsv1=creditcardmsgsrs)
  return ofx

def ofx_tostr(ofxroot, indent=2, fixutc=False):
  from ofxtools import header
  import xml.etree.ElementTree as ET
  
  for elem in ofxroot.iter():
    if fixutc and str(elem.text).__contains__('[+0:UTC]'):
      try:
        #elem.text = elem.text[:8]
        elem.text = elem.text.replace('[+0:UTC]', '')
        elem.text = datetime.strftime(datetime.strptime(elem.text, 
          '%Y%m%d%H%M%S.%f'), '%Y%m%d')
      except:
        print('Unable to replace elem.text: [+0:UTC]', file=sys.stderr)
  
  ET.indent(ofxroot, space=' '*indent)
  #ofxmessage = ET.tostring(ofxroot).decode()
  ofxmessage = ET.tostring(ofxroot, encoding='unicode')
  return str(header.make_header(version=220)) + ofxmessage

def parse_cmdopts(args=None):
  opts_parser = argparse.ArgumentParser()
  
  opts_parser.add_argument('balamt', nargs='?', default='0.00',
    help='Specify balance amount(default: 0.00)')
  opts_parser.add_argument('-b', '--baldate',
    default=datetime.now(tz=timezone.utc),
    type=lambda b: datetime.strptime(b+' +0000', '%Y-%m-%d %z'),
    help='Specify balance date(default: now)')
  opts_parser.add_argument('-t', '--accttype', default='CHECKING',
    choices=['CHECKING', 'CREDITCARD'],
    help='Specify account type(default: CHECKING)')
  opts_parser.add_argument('-q', '--qif', action='store_true', default=False,
    help='Transform CSV to QIF(default: False)')
  opts_parser.add_argument('-l', '--templatelib', default=None,
    choices=['None', 'mustache', 'liquid', 'eruby', 'jinja'],
    help='Specify template library(default: None)')
  opts_parser.add_argument('-i', '--infile', type=argparse.FileType('r'),
    default=sys.stdin, help='File in - (for stdin) or path(default: stdin)')
  opts_parser.add_argument('-o', '--outfile', type=argparse.FileType('w'),
    default=sys.stdout, help='File out - (for stdout) or path(default: stdout)')
  
  return opts_parser.parse_args(args)

def main(argv=None):
  import subprocess
  
  opts_hash = parse_cmdopts(argv)
  
  qiftype = 'CCard' if 'CREDITCARD' == opts_hash.accttype else 'Bank'
  cfg = {"langdef": LANGDEF, "curdef": CURDEF, "bankid": BANKID,
    "balamt": opts_hash.balamt, "baldate": opts_hash.baldate,
    "accttype": opts_hash.accttype, "acctdesc": None, "qiftype": qiftype,
    "dtserver": datetime.now(tz=timezone.utc)
  }
  (acctid, txnlist, dateplo, datephi) = deserialize_csv(opts_hash.infile)
  
  for txn in txnlist:
    txn['date'] = datetime.strptime(txn['date']+' +0000', '%Y/%m/%d %z')
  cfg.update({"acctid": acctid, "txnlist": txnlist,
    "dtstart": datetime.strptime(dateplo+' +0000', '%Y/%m/%d %z'),
    "dtend": datetime.strptime(datephi+' +0000', '%Y/%m/%d %z')})
  
  if str(opts_hash.templatelib) in ['eruby']:
    datefmt_spec = '%Y/%m/%d' if opts_hash.qif else '%Y%m%d%H%M%S.%f[+0:UTC]'
    #key_vals = map(lambda kv: '{0}={1}'.format(kv[0], kv[1]),
    #  filter(lambda el: not el[0] in ['txnlist', 'baldate', 'dtserver',
    #  'dtstart', 'dtend'], cfg.items()))
    key_vals = ['{0}={1}'.format(k, v) for k, v in cfg.items() 
      if not k in ['txnlist', 'baldate', 'dtserver', 'dtstart', 'dtend']]
    #key_vals.extend('baldate={0} dtserver={1} dtstart={2} dtend={3}'.format(
    #  datetime.strftime(cfg['baldate'], datefmt_spec),
    #  datetime.strftime(cfg['dtserver'], datefmt_spec),
    #  datetime.strftime(cfg['dtstart'], datefmt_spec),
    #  datetime.strftime(cfg['dtend'], datefmt_spec)).split())
    key_vals.extend(['{0}={1}'.format(dtX, datetime.strftime(cfg[dtX],
      datefmt_spec)) for dtX in ['baldate', 'dtserver', 'dtstart', 'dtend']])
    templatebase = 'qifsample.qif' if opts_hash.qif else \
      '{0}msgsrsv1.ofx'.format('creditcard' if 'CREDITCARD' == cfg.get(
      'accttype', 'CHECKING') else 'bank')
    template = os.path.join(SCRIPTPARENT, '_templates', 'eruby',
      '{0}.erb'.format(templatebase))
    
    opts_hash.infile.seek(0)
    res = subprocess.check_output('erb -T - {1} csvfile=- {0}'.format(
      template,' '.join(key_vals)).split(), stdin=opts_hash.infile, text=True)
    
    #opts_hash.outfile.write(res)
    print(res, file=opts_hash.outfile)
    return 0
  
  if not str(opts_hash.templatelib) in ['None', 'eruby']:
    res = render_sample(templatelib=opts_hash.templatelib, ctx=cfg,
      qif=opts_hash.qif)
  else:
    if opts_hash.qif:
      qif = csv_to_qif(cfg)
      res = qif.to_qif(date_format='%Y/%m/%d')
    else:
      ofx = csv_to_ofx(cfg)
      res = ofx_tostr(ofx.to_etree())
  
  #opts_hash.outfile.write(res)
  print(res, file=opts_hash.outfile)
  return 0


if '__main__' == __name__:
  import sys
  #raise SystemExit(main(sys.argv[1:]))
  sys.exit(main(sys.argv[1:]))


# xform_csv2ofx.py usage example:
#  balamt=`ledger bal --empty --balance-format "%(quantity(scrub(amount)))" {acct}`
#  [COLUMNORDER=account,date,payee,note,amount,comment] \
#    python xform_csv2ofx.py [-a [CHECKING|CREDITCARD]] [-i csvfile] [$balamt]
#  OR
#  ledger csv [--csv-format "%(account_base),%(date),%(payee),%(note),%(quantity(scrub(amount))),\n"] \
#    {acct} | sed 's|\\"||g' | \
#    [COLUMNORDER=account,date,payee,note,amount,comment] \
#    python xform_csv2ofx.py [-a [CHECKING|CREDITCARD]] [$balamt]
