#getpass_mailhome = 'secret'
#getpass_mailwork = 'secret'

from subprocess import check_output

def getpass_mail(acct):
  return check_output('gpg --no-tty -qd ~/.account-{0}.gpg'.format(acct),
    shell=True).strip('\n')
